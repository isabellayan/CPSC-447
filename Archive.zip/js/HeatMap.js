class HeatMap {
  /**
   * Class constructor with basic chart configuration
   */
  constructor(_config, _data) {
    this.config = {
      parentElement: _config.parentElement,
      vaccineIntroduced: _config.vaccineIntroduced,
      containerWidth: _config.containerWidth || 800,
      containerHeight: _config.containerHeight || 600,
      margin: _config.margin || { top: 65, right: 30, bottom: 60, left: 110 },
      tooltipPadding: _config.tooltipPadding || 15,
      legendWidth: 160,
      legendBarHeight: 10,
    };
    this.selectedCriteria = "sales";
    this.selectedRegion = "Global";
    this.selectedScore = "Critic";
    this.data = _data;
    this.genres = Array.from(new Set(this.data.map((d) => d.Genre)));
    this.platforms = Array.from(new Set(this.data.map((d) => d.Platform)));
    this.initVis();
  }

  /**
   * Initialize scales/axes and append static chart elements
   */
  initVis() {
    const vis = this;

    vis.config.width =
      vis.config.containerWidth -
      vis.config.margin.left -
      vis.config.margin.right;
    vis.config.height =
      vis.config.containerHeight -
      vis.config.margin.top -
      vis.config.margin.bottom;

    // initialize scales and axes
    vis.colorScale = d3.scaleSequential().interpolator(d3.interpolateBlues);

    // Ordered by earliest release date globally
    // PC
    // GB - 1989
    // PS - 1994
    // N64 - 1996
    // DC - 1998
    // WS - 1999
    // PS2 - 2000
    // GBA - Mar 2001
    // GC - Sept 2001
    // XB - Nov 2001
    // DS - Nov 2004
    // PSP - Dec 2004
    // X360 - 2005
    // PS3 - Nov 11 2006
    // Wii - Nov 19 2006
    // 3DS - Feb 2011
    // PSV - Dec 2011
    // WiiU - 2012
    // PS4 - Nov 15 2013
    // XOne - Nov 22 2013
    let platformSort = [
      "PC",
      "GB",
      "PS",
      "N64",
      "DC",
      "WS",
      "PS2",
      "GBA",
      "GC",
      "XB",
      "DS",
      "PSP",
      "X360",
      "PS3",
      "Wii",
      "3DS",
      "PSV",
      "WiiU",
      "PS4",
      "XOne",
    ];

    const uniqueGenre = [...new Set(vis.data.map((item) => item.Genre))];

    vis.xScale = d3
      .scaleBand()
      .domain(platformSort)
      .range([0, vis.config.width])
      .paddingInner(0.2);
    vis.yScale = d3
      .scaleBand()
      .domain(uniqueGenre)
      .range([0, vis.config.height])
      .paddingInner(0.2);

    vis.xAxis = d3.axisBottom(vis.xScale).ticks(6).tickSize(0).tickPadding(10);

    vis.yAxis = d3.axisLeft(vis.yScale).ticks(4).tickSize(0).tickPadding(10);

    // define svg drawing area
    vis.svg = d3
      .select(vis.config.parentElement)
      .attr("width", vis.config.containerWidth)
      .attr("height", vis.config.containerHeight);

    vis.chartArea = vis.svg
      .append("g")
      .attr(
        "transform",
        `translate(${vis.config.margin.left},${vis.config.margin.top})`
      );

    vis.chart = vis.chartArea.append("g");

    // Append empty x-axis group and move it to the bottom of the chart
    vis.xAxisG = vis.chartArea
      .append("g")
      .attr("class", "axis x-axis")
      .attr("transform", `translate(0,${vis.config.height})`);

    // Append y-axis group
    vis.yAxisG = vis.chartArea.append("g").attr("class", "axis y-axis");

    // Legend
    vis.legend = vis.svg
      .append("g")
      .attr(
        "transform",
        `translate(${
          vis.config.containerWidth -
          vis.config.legendWidth -
          vis.config.margin.right
        },25)`
      );

    vis.legendColorGradient = vis.legend
      .append("defs")
      .append("linearGradient")
      .attr("id", "linear-gradient");

    vis.legendColorRamp = vis.legend
      .append("rect")
      .attr("width", vis.config.legendWidth)
      .attr("height", vis.config.legendBarHeight)
      .attr("fill", "url(#linear-gradient)");

    vis.xLegendScale = d3.scaleLinear().range([0, vis.config.legendWidth]);

    vis.xLegendAxis = d3
      .axisBottom(vis.xLegendScale)
      .tickSize(vis.config.legendBarHeight + 3)
      .tickFormat(d3.format("d"));

    vis.xLegendAxisG = vis.legend
      .append("g")
      .attr("class", "axis x-axis legend-axis");

    // add axis titles
    vis.xAxisG
      .append("text")
      .attr("class", "axis-title")
      .attr("text-anchor", "middle")
      .attr("x", vis.config.width / 2)
      .attr("y", 55)
      .text("Platform");

    vis.yAxisG
      .append("text")
      .attr("class", "axis-title")
      .attr("text-anchor", "middle")
      .attr("x", -vis.config.height / 2 + 20)
      .attr("y", -80)
      .attr("transform", "rotate(-90)")
      .text("Genre");

    vis.updateVis();
  }

  /**
   * Prepare the data and scales before we render it.
   */
  updateVis() {
    const vis = this;

    // group data by genre and platform, and calculate total sales and mean score for each group
    const groupedData = d3.rollup(
      vis.data,
      (v) => ({
        sales: d3.sum(v, (d) =>
          vis.selectedRegion === "Global"
            ? d.Global_Sales
            : vis.selectedRegion === "NA"
            ? d.NA_Sales
            : vis.selectedRegion === "EU"
            ? d.EU_Sales
            : vis.selectedRegion === "JP"
            ? d.JP_Sales
            : d.Other_Sales
        ),
        meanScore: d3.mean(
          v.filter(
            (d) =>
              !isNaN(
                vis.selectedScore === "Critic" ? d.Critic_Score : d.User_Score
              )
          ),
          (d) =>
            vis.selectedScore === "Critic" ? d.Critic_Score : d.User_Score
        ),
      }),
      (d) => d.Genre,
      (d) => d.Platform
    );

    vis.groups = Array.from(groupedData, ([genre, platform]) => ({
      genre: genre,
      platform: Array.from(platform, ([platform, values]) => ({
        platform: platform,
        sales: values.sales,
        score: values.meanScore,
      })),
    }));

    // fill groups that have no data with null sales to avoid gaps in the heatmap
    vis.groups.forEach((group) => {
      vis.platforms.forEach((platform) => {
        if (!group.platform.some((d) => d.platform === platform)) {
          group.platform.push({
            platform: platform,
            sales: null,
            score: null,
          });
        }
      });
    });

    // Specify accessor functions
    vis.xValue = (d) => d.platform;
    vis.yValue = (d) => d.genre;
    vis.colorValue = (d) =>
      vis.selectedCriteria === "sales" ? d.sales : d.score;

    // Set the scale input domains
    vis.colorScale.domain([
      d3.min(vis.groups, (d) => d3.min(d.platform, vis.colorValue)),
      d3.max(vis.groups, (d) => d3.max(d.platform, vis.colorValue)),
    ]);

    vis.renderVis();
    vis.renderLegend();
  }

  /**
   * Bind data to visual elements.
   */
  renderVis() {
    const vis = this;

    // 1. Level: rows
    const row = vis.chart.selectAll(".h-row").data(vis.groups, (d) => d.genre);

    // Enter
    const rowEnter = row
      .enter()
      .append("g")
      .attr("class", (d) => d.genre + " h-row");

    // Enter + update
    rowEnter
      .merge(row)
      .classed("highlight", function (d) {
        if (SelectGame && SelectGame.Genre === d.genre) {
          return true; // add the class if the condition is true
        } else {
          return false; // remove the class if the condition is false
        }
      })
      .attr("transform", (d) => `translate(0,${vis.yScale(vis.yValue(d))})`);

    // add mouse click event to each row
    rowEnter.merge(row).on("click", (event, d) => {
      d3.selectAll("*")
        .filter(function () {
          return (
            d3.select(this).classed(d.genre) &&
            d3.select(this).classed("bubble")
          );
        })
        .node()
        .dispatchEvent(
          new MouseEvent("click", {
            bubbles: true,
            cancelable: true,
            view: window,
          })
        );
      if (SelectGame !== "") {
        resetSearch();
      }
    });

    // Exit
    row.exit().remove();

    // 2. Level: columns

    // 2a) Actual cells
    const cell = row
      .merge(rowEnter)
      .selectAll(".h-cell")
      .data((d) => d.platform);

    // Enter
    const cellEnter = cell.enter().append("rect").attr("class", "h-cell");

    // Enter + update
    cellEnter
      .merge(cell)
      .transition()
      .duration(800)
      .attr("height", vis.yScale.bandwidth())
      .attr("width", vis.xScale.bandwidth())
      .attr("x", (d) => vis.xScale(vis.xValue(d)))
      .attr("fill", (d) => {
        if (
          vis.colorValue(d) === 0 ||
          vis.colorValue(d) === null ||
          vis.colorValue(d) === undefined
        ) {
          return "#fff";
        } else {
          return vis.colorScale(vis.colorValue(d));
        }
      });

    // Tooltip
    cellEnter
      .merge(cell)
      .on("mousemove", (event, d) => {
        d3.select("#tooltip")
          .style("display", "block")
          .style("left", event.pageX + vis.config.tooltipPadding + "px")
          .style("top", event.pageY + vis.config.tooltipPadding + "px")
          .html(
            `<div class='tooltip-title'> ${
              vis.colorValue(d) == (null || undefined)
                ? "No Data Available"
                : vis.selectedCriteria === "sales"
                ? "Total Sales"
                : "Mean " + vis.selectedScore + " Score"
            }</div>
          <div><i> ${
            vis.colorValue(d) == (null || undefined)
              ? ""
              : vis.selectedCriteria === "sales"
              ? Math.round(d.sales * 100) / 100
              : Math.round(d.score, 2)
          }
          ${
            vis.colorValue(d) == (null || undefined)
              ? ""
              : vis.selectedCriteria === "sales"
              ? "Million of units"
              : ""
          }
          </i></div>`
          );
      })
      .on("mouseleave", () => {
        d3.select("#tooltip").style("display", "none");
      })
      .on("mouseover", function () {
        let row = d3.select(this.parentNode);
        row.classed("hovering", true);
      })
      .on("mouseout", function () {
        let row = d3.select(this.parentNode);
        row.classed("hovering", false);
      });

    // 2b) Diagonal lines for NA values
    const cellNa = row
      .merge(rowEnter)
      .selectAll(".h-cell-na")
      .data((d) =>
        d.platform.filter(
          (k) => vis.colorValue(k) === null || vis.colorValue(k) === undefined
        )
      );

    const cellNaEnter = cellNa
      .enter()
      .append("line")
      .attr("class", "h-cell-na");

    cellNaEnter
      .merge(cellNa)
      .transition()
      .duration(800)
      .attr("x1", (d) => vis.xScale(vis.xValue(d)))
      .attr("x2", (d) => vis.xScale(vis.xValue(d)) + vis.xScale.bandwidth())
      .attr("y1", vis.yScale.bandwidth())
      .attr("y2", 0);

    // Exit
    cellNa.exit().remove();

    // Update axis
    vis.xAxisG.call(vis.xAxis);
    vis.yAxisG.call(vis.yAxis);
  }

  /**
   * Update colour legend
   */
  renderLegend() {
    const vis = this;

    // Add stops to the gradient
    vis.legendColorGradient
      .selectAll("stop")
      .data(vis.colorScale.range())
      .join("stop")
      .attr("offset", (d, i) => i / (vis.colorScale.range().length - 1))
      .attr("stop-color", (d) => d);

    // Set x-scale and reuse colour-scale because they share the same domain
    // Round values using `nice()` to make them easier to read.
    vis.xLegendScale.domain(vis.colorScale.domain()).nice();
    const extent = vis.xLegendScale.domain();

    // Manually calculate tick values
    vis.xLegendAxis.tickValues([
      extent[0],
      parseInt((extent[1] - extent[0]) / 3 + extent[0]),
      parseInt(((extent[1] - extent[0]) / 3) * 2 + extent[0]),
      extent[1],
    ]);

    // Update legend axis
    vis.xLegendAxisG.call(vis.xLegendAxis);
  }
}
