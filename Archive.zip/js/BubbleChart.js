// Copyright 2021 Observable, Inc.
// Released under the ISC license.
// https://observablehq.com/@d3/bubble-chart
class BubbleChart {
  /**
   * Class constructor with basic chart configuration
   */
  constructor(_config, _data) {
    this.config = {
      parentElement: _config.parentElement,
      containerWidth: _config.containerWidth || 350,
      containerHeight: _config.containerHeight || 350,
      margin: _config.margin || { top: 1, right: 1, bottom: 1, left: 1 },
      tooltipPadding: _config.tooltipPadding || 15,
    };
    this.data = _data;

    this.name = ([x]) => x; // alias for label
    this.label = (d) => d.key; // given d in data, returns text to display on the bubble
    this.value = (d) => d.count; // given d in data, returns a quantitative size
    this.group = (d) => d.key; // given d in data, returns a categorical value for color
    this.title = (d) => d.key; // given d in data, returns text to show on hover
    this.link = null; // given a node d, its link (if any)
    this.linkTarget = "_blank"; // the target attribute for links, if any
    this.padding = 3; // padding between circles
    this.groups = null; // array of group names (the domain of the color scale)
    this.colors = d3.schemeSet3; // an array of colors (for groups)
    this.fill = "#ccc"; // a static fill color, if no group channel is specified
    this.fillOpacity = 1.0; // the fill opacity of the bubbles
    this.stroke = null; // a static stroke around the bubbles
    this.strokeWidth = null; // the stroke width around the bubbles, if any
    this.strokeOpacity = null; // the stroke opacity around the bubbles, if any

    this.initVis();
  }

  /**
   * Initialize scales/axes and append static chart elements
   */
  initVis() {
    let vis = this;

    vis.width =
      vis.config.containerWidth -
      vis.config.margin.left -
      vis.config.margin.right;
    vis.height =
      vis.config.containerHeight -
      vis.config.margin.top -
      vis.config.margin.bottom;

    vis.svg = d3
      .select(vis.config.parentElement)
      .attr("width", vis.config.containerWidth)
      .attr("height", vis.config.containerHeight)
      .attr("viewBox", [
        -vis.config.margin.left,
        -vis.config.margin.top,
        vis.config.containerWidth,
        vis.config.containerHeight,
      ])
      .attr("style", "max-width: 100%; height: auto; height: intrinsic;")
      .attr("fill", "currentColor")
      .attr("font-size", 12)
      .attr("font-family", "sans-serif")
      .attr("text-anchor", "middle");

    vis.svg
      .append("text")
      .attr("class", "axis-title")
      .attr("x", 70)
      .attr("y", 0)
      .attr("dy", ".71em")
      .attr("font-size", 14);

    // Add a rectangle with the size of the graph
    const rect = vis.svg
      .append("rect")
      .attr("class", "reset-chart-area")
      .attr("x", 0)
      .attr("y", 0)
      .attr("width", vis.width)
      .attr("height", vis.height)
      .attr("opacity", 0);

    vis.renderVis();
  }

  /**
   * Prepare the data and scales, bind data to visual elements
   */
  renderVis() {
    let vis = this;

    // axis title
    vis.svg.select(".axis-title").text(`# of games : ${vis.data.length}`);

    // Prepare data: count number of games for each genre
    const aggregatedDataMap = d3.rollups(
      vis.data,
      (v) => v.length,
      (d) => d.Genre
    );
    vis.aggregatedData = Array.from(aggregatedDataMap, ([key, count]) => ({
      key,
      count,
    }));

    vis.yValue = (d) => d.count;

    // Compute the values.
    const D = d3.map(vis.aggregatedData, (d) => d);
    const V = d3.map(vis.aggregatedData, vis.yValue);
    const G = vis.group == null ? null : d3.map(vis.aggregatedData, vis.group);
    const I = d3.range(V.length).filter((i) => V[i] > 0);

    // Unique the groups.
    if (G && vis.groups === undefined) vis.groups = I.map((i) => G[i]);
    vis.groups = G && new Set(vis.groups);

    // Construct scales.
    const color = G && d3.scaleOrdinal(vis.groups, vis.colors);

    // Compute labels and titles.
    const L = vis.label == null ? null : d3.map(vis.aggregatedData, vis.label);
    const T =
      vis.title === undefined
        ? L
        : vis.title == null
        ? null
        : d3.map(vis.aggregatedData, vis.title);

    // Compute layout: create a 1-deep hierarchy, and pack it.
    const root = d3.pack().size([vis.width, vis.height]).padding(vis.padding)(
      d3.hierarchy({ children: I }).sum((i) => V[i])
    );

    const leaf = vis.svg
      .selectAll("a")
      .data(root.leaves())
      .join("a")
      .attr(
        "xlink:href",
        vis.link == null ? null : (d, i) => vis.link(D[d.data], i, data)
      )
      .attr("target", vis.link == null ? null : vis.linkTarget)
      .attr("transform", (d) => `translate(${d.x},${d.y})`);

    leaf
      .selectAll("circle")
      .data((d) => d)
      .join("circle")
      .attr("class", "bubble")
      .attr("stroke", vis.stroke)
      .attr("stroke-width", vis.strokeWidth)
      .attr("stroke-opacity", vis.strokeOpacity)
      .attr("fill", function (d) {
        return SelectGame !== ""
          ? SelectGame.Genre === G[d.data]
            ? "hotpink"
            : "steelblue"
          : G
          ? color(G[d.data])
          : vis.fill == null
          ? "none"
          : vis.fill;
      })
      .attr("fill-opacity", vis.fillOpacity)
      .transition()
      .duration(800)
      .attr("r", (d) => d.r);

    if (L) {
      // A unique identifier for clip paths (to avoid conflicts).
      const uid = `O-${Math.random().toString(16).slice(2)}`;

      leaf
        .selectAll("clipPath")
        .data((d) => d)
        .join("clipPath")
        .attr("id", (d) => `${uid}-clip-${d.data}`)
        .append("circle")
        .attr("r", (d) => d.r);

      leaf
        .selectAll("text")
        .data((d) => d)
        .join("text")
        .attr(
          "clip-path",
          (d) => `url(${new URL(`#${uid}-clip-${d.data}`, location)})`
        )
        .selectAll("tspan")
        .data((d) => d)
        .join("tspan")
        .attr("x", 0)
        .attr("y", (d, i, D) => `${i - D.length / 2 + 0.85}em`)
        .attr("fill-opacity", (d, i, D) => (i === D.length - 1 ? 0.7 : null))
        .attr("class", (d) => {
          let ret = `${L[d.data]}`.split(/\n/g);
          return `tspan ${ret}`;
        })
        .text((d) => (d.r > 30 ? `${L[d.data]}`.split(/\n/g) : ""));
    }

    // Select all the 'a' elements
    let aElements = d3.selectAll("svg#bubble-chart a");

    // Loop through each 'a' element and add the genre names into the class for the texts and circles
    aElements.each(function () {
      const textElement = d3.select(this).select("text");
      const tspanElement = d3.select(this).select("tspan");
      const circleElement = d3.select(this).select("circle");
      const tspanClassName = tspanElement.node().classList;

      textElement.node().classList.remove(...textElement.node().classList);
      textElement.node().classList.add("text", tspanClassName[1]);

      circleElement.classed(`${tspanClassName[1]}`, true);
      if (selectedGenres.includes(tspanClassName[1])) {
        circleElement.classed(`select`, true);
      }
    });

    // Change the class of the circles on click
    vis.svg.on("click", function (event) {
      if (SelectGame !== "") {
        resetSearch();
        updateTable();
      }
      if (event.target.tagName === "circle") {
        const circle = d3.select(event.target);
        const genre = event.target.classList[1];
        const isSelected = circle.classed("select");
        circle.classed("select", !isSelected);
        if (isSelected) {
          selectedGenres = selectedGenres.filter((f) => f !== genre); // Remove from list
        } else {
          selectedGenres.push(genre); // Append to list
        }
        // update heatmap row
        d3.selectAll("*")
          .filter(function () {
            if (
              d3.select(this).classed(genre) &&
              d3.select(this).classed("h-row") &&
              !d3.select(this).classed("active")
            ) {
              return true;
            } else if (
              d3.select(this).classed(genre) &&
              d3.select(this).classed("h-row") &&
              d3.select(this).classed("active")
            ) {
              d3.select(this).classed("active", false);
              return false;
            } else {
              return false;
            }
          })
          .classed("active", true);
      }

      updateTable();
    });

    // Remove all selected genres if clicked on the chart (not on the circles)
    vis.svg.on("mousedown", function (event) {
      if (event.target.tagName === "rect") {
        d3.selectAll(".active").classed("active", false);
        selectedGenres = [];
        if (SelectGame !== "") {
          resetSearch();
        }
        d3.selectAll("circle").classed("select", false);
        vis.renderVis();
      }
    });

    // Add tooltip on hover
    vis.svg.on("mousemove", function (event) {
      if (event.target.tagName === "circle") {
        // display a tooltip when hover
        d3
          .select("#tooltip")
          .style("display", "block")
          .style("left", event.pageX + vis.config.tooltipPadding + "px")
          .style("top", event.pageY + vis.config.tooltipPadding + "px").html(`
              <div class="tooltip-title">${event.target.classList[1]}</div>
              <div><i># of games: ${
                d3.select(event.target).data()[0].value
              }</i></div>`);
      }
    });

    vis.svg.on("mouseout", function (event) {
      d3.select("#tooltip").style("display", "none");
    });

    return Object.assign(vis.svg.node(), { scales: { color } });
  }
}
