let data, lineChart, bubbleChart, table, Heatmap;
let selectedYears = [];
let selectedGenres = [];
let SelectGame = "";
let search = d3.select("#search");
let selectedCriteria = "sales";

d3.csv("data/video_games_2000_to_2016.csv").then((_data) => {
  // preprocess the data
  _data.forEach((d) => {
    d.Index = +d.Index;
    d.Critic_Count = d.Critic_Count === "" ? null : +d.Critic_Count;
    d.Critic_Score = d.Critic_Score === "" ? null : +d.Critic_Score;
    d.Global_Sales = +d.Global_Sales;
    d.EU_Sales = +d.EU_Sales;
    d.NA_Sales = +d.NA_Sales;
    d.JP_Sales = +d.JP_Sales;
    d.Other_Sales = +d.Other_Sales;
    d.User_Count = d.User_Count === "" ? null : +d.User_Count;
    d.Year_of_Release = +d.Year_of_Release;

    d.User_Score =
      d.User_Score === ""
        ? null
        : d.User_Score === "tbd"
        ? "tbd"
        : +d.User_Score * 10;
  });

  data = _data;

  lineChart = new LineChart({ parentElement: "#line-chart" }, _data);
  bubbleChart = new BubbleChart({ parentElement: "#bubble-chart" }, _data);
  table = new Table({ chartElement: "#table-chart" }, _data);
  Heatmap = new HeatMap({ parentElement: "#heatmap" }, _data);

  // Search for games and display it when typing game title in the search box
  let optionList = data.map((d) => d.Name);

  search.on("input", function () {
    let query = this.value.toLowerCase();

    if (query.length === 0) {
      d3.select("#options").style("display", "none");
    } else {
      d3.select("#options").style("display", "block");
    }

    let matches = d3
      .select("#options")
      .selectAll(".option")
      .data(
        optionList.filter(function (option) {
          return option.toLowerCase().includes(query);
        })
      );

    let inputRect = search.node().getBoundingClientRect();
    let containerRect = d3
      .select("#search-container")
      .node()
      .getBoundingClientRect();

    d3.select("#options")
      .style("position", "fixed")
      .style("top", inputRect.bottom - containerRect.top + 18 + "px")
      .style("left", inputRect.left + "px")
      .style("width", inputRect.width + "px");

    // Add user input recommendations
    matches
      .join("div")
      .classed("option", true)
      .text(function (d) {
        return d;
      })
      .on("click", function (d) {
        search.property("value", d.srcElement.textContent);
        d3.select("#options").html("").style("top", "-1px");

        SelectGame = data
          .filter((s) => s.Name === d.srcElement.textContent.toString())
          .sort((d) => d3.ascending(d.User_Score))[0];

        selectedYears = [];
        lineChart.updateVis();

        table.data = data.filter(
          (s) => s.Name === d.srcElement.textContent.toString()
        );

        selectedGenres = [];
        document.getElementById("table-title").innerHTML = "Selected Game";

        bubbleChart.data = data;
        bubbleChart.renderVis();

        Heatmap.data = data;

        const activeElements = document.querySelectorAll(".active");
        activeElements.forEach((element) => {
          element.classList.remove("active");
        });

        Heatmap.updateVis();
        table.updateVis();
      });
  });

  // Display a random game when clicking on the dice button
  const myImage = document.getElementById("dice");

  myImage.addEventListener("click", function () {
    const randomIndex = Math.floor(Math.random() * data.length);
    SelectGame = data[randomIndex];

    selectedYears = [];
    lineChart.updateVis();

    table.data = Array.of(SelectGame);

    selectedYears = [];
    selectedGenres = [];

    document.getElementById("table-title").innerHTML = "Random Game";

    bubbleChart.data = data;
    bubbleChart.renderVis();

    const activeElements = document.querySelectorAll(".active");
    activeElements.forEach((element) => {
      element.classList.remove("active");
    });

    Heatmap.data = data;
    Heatmap.updateVis();

    table.updateVis();
  });

  // Change all views when the first dropdown changes
  d3.select("#selector").on("change", function () {
    selectedCriteria = d3.select(this).property("value");
    let regionSelector = d3.select("#region-selector");
    let scoreSelector = d3.select("#score-selector");

    regionSelector.style(
      "pointer-events",
      selectedCriteria === "sales" ? "auto" : "none"
    );
    scoreSelector.style(
      "pointer-events",
      selectedCriteria === "sales" ? "none" : "auto"
    );

    regionSelector.style(
      "background-color",
      selectedCriteria === "sales" ? "" : "#ccc"
    );
    scoreSelector.style(
      "background-color",
      selectedCriteria === "sales" ? "#ccc" : ""
    );

    let lineChartHeading = document.getElementById("line-chart-title");
    let heatmapHeading = document.getElementById("heatmap-title");
    let tableHeading = document.getElementById("table-title");

    if (selectedCriteria === "sales") {
      lineChartHeading.innerHTML = "Total sales by year";
      heatmapHeading.innerHTML = "Total sales by genre and platform";
      tableHeading.innerHTML = "Top 10 Best Sellers";
      document.getElementById("lower-charts-container").style.left = "50px";
    } else {
      lineChartHeading.innerHTML = "Mean score by year";
      heatmapHeading.innerHTML = "Mean score by genre and platform";
      tableHeading.innerHTML = "Top 10 Highest Scored";
    }

    lineChart.selectedCriteria = selectedCriteria;
    table.selectedCriteria = selectedCriteria;
    Heatmap.selectedCriteria = selectedCriteria;
    lineChart.updateVis();
    bubbleChart.renderVis();
    table.updateVis();
    Heatmap.updateVis();
  });
});

// reset all views when returned from the search/random result screen
function resetSearch() {
  SelectGame = "";
  selectedYears = [];
  selectedGenres = [];
  search.property("value", "");
  document.getElementById("table-title").innerHTML =
    selectedCriteria === "sales"
      ? "Top 10 Best Sellers"
      : "Top 10 Highest Scored";

  lineChart.updateVis();
  bubbleChart.data = data;
  bubbleChart.renderVis();
  Heatmap.data = data;
  Heatmap.updateVis();
  table.data = data;
  table.updateVis();
}

// Change all views (except bubble) when the second dropdown changes
d3.select("#region-selector").on("change", function () {
  let selectedRegion = d3.select(this).property("value");

  lineChart.selectedRegion = selectedRegion;
  table.selectedRegion = selectedRegion;
  Heatmap.selectedRegion = selectedRegion;
  lineChart.updateVis();
  table.updateVis();
  Heatmap.updateVis();
});

// Change all views (except bubble) when the third dropdown changes
d3.select("#score-selector").on("change", function () {
  let selectedScore = d3.select(this).property("value");

  lineChart.selectedScore = selectedScore;
  table.selectedScore = selectedScore;
  Heatmap.selectedScore = selectedScore;
  lineChart.updateVis();
  table.updateVis();
  Heatmap.updateVis();
});

// Take user to the visualizations when clicking on the button on the welcome page
let button = document.getElementById("toViz");
button.addEventListener("click", function () {
  let div = document.getElementById("filters");
  let rect = div.getBoundingClientRect();
  let topPos = rect.top + window.pageYOffset - 50;
  window.scrollTo({ top: topPos, behavior: "smooth" });
});

// Add slider for the line chart
let slider = document.getElementById("slider");
noUiSlider.create(slider, {
  start: [2000, 2016],
  connect: true,
  step: 1,
  range: {
    min: 2000,
    max: 2016,
  },
});

// Display slider values
slider.noUiSlider.on("update", function (values, handle) {
  document.getElementById("minValue").textContent = Math.round(values[0]);
  document.getElementById("maxValue").textContent = Math.round(values[1]);
});

// Change all views when slider changes (same as clicking on points on the line chart)
slider.noUiSlider.on("change", function (values, handle) {
  let min = Math.round(values[0]);
  let max = Math.round(values[1]);

  selectedYears = [];
  for (let i = min; i <= max; i++) {
    selectedYears.push(i);
  }
  lineChart.selectedBy = "slider";

  lineChart.updateVis();
  updateTable();
  updateHeatMap();
  updateBubbleChart();
});

// update the table
function updateTable() {
  let table_genre =
    selectedGenres.length === 0
      ? data
      : data.filter((d) => selectedGenres.includes(d.Genre));
  let table_year =
    selectedYears.length === 0
      ? table_genre
      : table_genre.filter((d) => selectedYears.includes(d.Year_of_Release));
  table.data = table_year;
  table.updateVis();
}

// update the heatmap
function updateHeatMap() {
  if (selectedYears.length === 0) {
    Heatmap.data = data;
  } else {
    Heatmap.data = data.filter((d) =>
      selectedYears.includes(d.Year_of_Release)
    );
  }
  Heatmap.updateVis();
}

// update the bubble chart
function updateBubbleChart() {
  if (selectedYears.length === 0) {
    bubbleChart.data = data;
  } else {
    bubbleChart.data = data.filter((d) =>
      selectedYears.includes(d.Year_of_Release)
    );
  }
  bubbleChart.renderVis();
}

// update line chart
function updateLine(data) {
  lineChart.data = data;
  lineChart.updateVis();
}

// update bubble chart (call updateVis with new data)
function updateBubble(data) {
  bubbleChart.data = data;
  bubbleChart.updateVis();
}

// update heatmap (call updateVis with new data)
function updateHeat(data) {
  Heatmap.data = data;
  Heatmap.updateVis();
}
