class Table {
  /**
   * Class constructor with basic configuration
   */
  constructor(_config, _data) {
    this.config = {
      chartElement: _config.chartElement,
      tooltipPadding: _config.tooltipPadding || 15,
    };
    this.data = _data;
    this.selectedCriteria = "sales";
    this.selectedRegion = "Global";
    this.selectedScore = "Critic";
    this.initVis();
  }

  /**
   * Initialize table
   */
  initVis() {
    let vis = this;

    vis.table = d3
      .select(vis.config.chartElement)
      .append("table")
      .attr("class", "table");

    vis.thead = vis.table.append("thead");
    vis.tbody = vis.table.append("tbody");

    vis.updateVis();
  }

  /**
   * Prepare the data before we place it in the table.
   */
  updateVis() {
    let vis = this;

    // Sort data for the top 10 bestsellers and highest scored
    if (vis.selectedRegion === "Global") {
      vis.rank = vis.data
        .sort(function (a, b) {
          return b.Global_Sales - a.Global_Sales;
        })
        .slice(0, 10);
    } else if (vis.selectedRegion === "NA") {
      vis.rank = vis.data
        .sort(function (a, b) {
          return b.NA_Sales - a.NA_Sales;
        })
        .slice(0, 10);
    } else if (vis.selectedRegion === "EU") {
      vis.rank = vis.data
        .sort(function (a, b) {
          return b.EU_Sales - a.EU_Sales;
        })
        .slice(0, 10);
    } else if (vis.selectedRegion === "JP") {
      vis.rank = vis.data
        .sort(function (a, b) {
          return b.JP_Sales - a.JP_Sales;
        })
        .slice(0, 10);
    } else {
      vis.rank = vis.data
        .sort(function (a, b) {
          return b.Other_Sales - a.Other_Sales;
        })
        .slice(0, 10);
    }

    // If nothing is selected then filter out null data and generate our visualization
    vis.score =
      SelectGame === ""
        ? vis.data
            .filter((d) =>
              vis.selectedScore === "Critic"
                ? d.Critic_Score !== null
                : (d.User_Score !== "tbd") & (d.User_Score !== null)
            )
            .sort((a, b) =>
              vis.selectedScore === "Critic"
                ? d3.descending(a.Critic_Score, b.Critic_Score)
                : d3.descending(a.User_Score, b.User_Score)
            )
            .slice(0, 10)
        : vis.data;

    vis.criticNotAvaliable = vis.data.filter((d) => d.Critic_Score === null);
    vis.userNotAvaliable = vis.data.filter(
      (d) => d.User_Score === null || d.User_Score === "tbd"
    );

    vis.score =
      vis.score.length >= 10
        ? vis.score
        : vis.selectedScore === "Critic"
        ? vis.score.concat(vis.criticNotAvaliable)
        : vis.score.concat(vis.userNotAvaliable);

    vis.score = vis.score.slice(0, 10);

    vis.renderVis();
  }

  /**
   * Bind data to table
   */
  renderVis() {
    const vis = this;

    // Add table header
    vis.thead
      .join("tr")
      .selectAll("th")
      .data([
        "Name",
        "Year",
        "Platform",
        "Genre",
        vis.selectedCriteria === "sales" ? "Sales /mil of units" : "Score",
      ])
      .join("th")
      .text((d) => d);

    // Add table contents
    const rows = vis.tbody
      .selectAll("tr")
      .data(vis.selectedCriteria === "sales" ? vis.rank : vis.score)
      .join("tr");

    rows
      .selectAll("td")
      .data((d) => [
        d.Name,
        d.Year_of_Release,
        d.Platform,
        d.Genre === "Role-Playing" ? "RPG" : d.Genre,
        vis.selectedCriteria === "sales"
          ? vis.selectedRegion === "Global"
            ? d.Global_Sales
            : vis.selectedRegion === "NA"
            ? d.NA_Sales
            : vis.selectedRegion === "EU"
            ? d.EU_Sales
            : vis.selectedRegion === "JP"
            ? d.JP_Sales
            : d.Other_Sales
          : vis.selectedScore === "Critic"
          ? d.Critic_Score === null || d.Critic_Score === "tbd"
            ? "No Information"
            : d.Critic_Score
          : d.User_Score === null || d.User_Score === "tbd"
          ? "No Information"
          : d.User_Score,
      ])
      .join("td")
      .html(function (d) {
        return d;
      })
      .style("opacity", 0)
      .transition()
      .duration(800)
      .style("opacity", 1);

    // Add tooltip
    rows
      .on("mousemove", (event, d) => {
        var tooltipHtml = `
        <div class='tooltip-title'> ${d.Name}</div>
        <div><i> Publisher: ${d.Publisher}</i></div>
    `;

        if (vis.selectedCriteria === "sales") {
          if (vis.selectedRegion !== "Global") {
            tooltipHtml += `<div><i> Global Sales: ${d.Global_Sales} Million of units</i></div>`;
          }
          if (vis.selectedRegion !== "NA") {
            tooltipHtml += `<div><i> NA Sales: ${d.NA_Sales} Million of units</i></div>`;
          }
          if (vis.selectedRegion !== "EU") {
            tooltipHtml += `<div><i> EU Sales: ${d.EU_Sales} Million of units</i></div>`;
          }
          if (vis.selectedRegion !== "JP") {
            tooltipHtml += `<div><i> JP Sales: ${d.JP_Sales} Million of units</i></div>`;
          }
          if (vis.selectedRegion !== "Other") {
            tooltipHtml += `<div><i> Other Sales: ${d.Other_Sales} Million of units</i></div>`;
          }
        } else {
          tooltipHtml += `
        <div><i> Global Sales: ${d.Global_Sales} Million of units</i></div>
        <div><i> NA Sales: ${d.NA_Sales} Million of units</i></div>
        <div><i> EU Sales: ${d.EU_Sales} Million of units</i></div>
        <div><i> JP Sales: ${d.JP_Sales} Million of units</i></div>
        <div><i> Other Sales: ${d.Other_Sales} Million of units</i></div>
    `;
        }

        if (vis.selectedCriteria === "sales") {
          tooltipHtml += `<div><i> Critic Score: ${
            d.Critic_Score === null ? "No Information" : d.Critic_Score
          }</i></div>
                        <div><i> Critic Count: ${
                          d.Critic_Count === null
                            ? "No Information"
                            : d.Critic_Count
                        }</i></div>
                        <div><i> User Score: ${
                          d.User_Score === null
                            ? "No Information"
                            : d.User_Score
                        }</i></div>
                        <div><i> User Count: ${
                          d.User_Count === null
                            ? "No Information"
                            : d.User_Count
                        }</i></div>`;
        } else if (vis.selectedScore === "Critic") {
          tooltipHtml += `<div><i> Critic Count: ${
            d.Critic_Count === null ? "No Information" : d.Critic_Count
          }</i></div>
                          <div><i> User Score: ${
                            d.User_Score === null
                              ? "No Information"
                              : d.User_Score
                          }</i></div>
                          <div><i> User Count: ${
                            d.User_Count === null
                              ? "No Information"
                              : d.User_Count
                          }</i></div>`;
        } else if (vis.selectedScore === "User") {
          tooltipHtml += `<div><i> Critic Score: ${
            d.Critic_Score === null ? "No Information" : d.Critic_Score
          }</i></div>
                        <div><i> Critic Count: ${
                          d.Critic_Count === null
                            ? "No Information"
                            : d.Critic_Count
                        }</i></div>
                        <div><i> User Count: ${
                          d.User_Count === null
                            ? "No Information"
                            : d.User_Count
                        }</i></div>`;
        }

        d3.select("#tooltip")
          .style("display", "block")
          .style("left", event.pageX + vis.config.tooltipPadding + "px")
          .style("top", event.pageY + vis.config.tooltipPadding + "px")
          .html(tooltipHtml);
      })
      .on("mouseleave", () => {
        d3.select("#tooltip").style("display", "none");
      });
  }
}
