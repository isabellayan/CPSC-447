class LineChart {
  /**
   * Class constructor with basic chart configuration
   */
  constructor(_config, _data) {
    this.config = {
      parentElement: _config.parentElement,
      containerWidth: _config.containerWidth || 800,
      containerHeight: _config.containerHeight || 250,
      margin: _config.margin || { top: 25, right: 30, bottom: 30, left: 50 },
      tooltipPadding: _config.tooltipPadding || 15,
    };
    this.data = _data;
    this.selectedCriteria = "sales";
    this.selectedRegion = "Global";
    this.selectedScore = "Critic";
    this.selectedBy = "point";
    this.initVis();
  }

  /**
   * Initialize scales/axes and append static chart elements
   */
  initVis() {
    let vis = this;

    // Initialize width and height of the chart
    vis.width =
      vis.config.containerWidth -
      vis.config.margin.left -
      vis.config.margin.right;
    vis.height =
      vis.config.containerHeight -
      vis.config.margin.top -
      vis.config.margin.bottom;

    // Initialize scale
    vis.xScale = d3
      .scaleTime()
      .domain([new Date(2000, 0, 1), new Date(2016, 0, 1)])
      .range([0, vis.width]);

    vis.yScale = d3.scaleLinear().range([vis.height, 0]).nice();

    // Initialize axes
    vis.xAxis = d3
      .axisBottom(vis.xScale)
      .ticks(6)
      .tickSizeOuter(0)
      .tickPadding(10);

    vis.yAxis = d3
      .axisLeft(vis.yScale)
      .ticks(4)
      .tickSizeOuter(0)
      .tickPadding(10)
      .tickSize(-vis.width);

    // Define size of SVG drawing area
    vis.svg = d3
      .select(vis.config.parentElement)
      .attr("width", vis.config.containerWidth)
      .attr("height", vis.config.containerHeight);

    // Append group element that will contain our actual chart (see margin convention)
    vis.chart = vis.svg
      .append("g")
      .attr(
        "transform",
        `translate(${vis.config.margin.left},${vis.config.margin.top})`
      );

    // Add a rectangle with the size of the graph
    const rect = vis.chart
      .append("rect")
      .attr("class", "reset-chart-area")
      .attr("x", 0)
      .attr("y", 0)
      .attr("width", vis.width)
      .attr("height", vis.height)
      .attr("opacity", 0);

    // Append empty x-axis group and move it to the bottom of the chart
    vis.xAxisG = vis.chart
      .append("g")
      .attr("class", "axis x-axis")
      .attr("transform", `translate(0,${vis.height})`);

    // Append y-axis group
    vis.yAxisG = vis.chart.append("g").attr("class", "axis y-axis");

    // Add axis title
    vis.svg
      .append("text")
      .attr("class", "axis-title")
      .attr("x", 0)
      .attr("y", 5)
      .attr("dy", ".71em");

    vis.updateVis();
  }

  /**
   * Prepare the data and scales before we render it.
   */
  updateVis() {
    let vis = this;

    // Prepare data: sum the number of sales and calculate the mean scores for each year
    vis.aggregatedData = vis.data
      .reduce((acc, obj) => {
        const year = obj.Year_of_Release;
        const value =
          vis.selectedRegion === "Global"
            ? obj.Global_Sales
            : vis.selectedRegion === "NA"
            ? obj.NA_Sales
            : vis.selectedRegion === "EU"
            ? obj.EU_Sales
            : vis.selectedRegion === "JP"
            ? obj.JP_Sales
            : obj.Other_Sales;
        const score =
          vis.selectedScore === "Critic" ? obj.Critic_Score : obj.User_Score;
        const yearIndex = acc.findIndex(
          (el) => el.year.getTime() === new Date(year, 0).getTime()
        );
        if (yearIndex === -1) {
          acc.push({ year: new Date(year, 0), value: value, score: [score] });
        } else {
          acc[yearIndex].value += value;
          acc[yearIndex].score.push(score);
        }

        return acc;
      }, [])
      .map((obj) => {
        return {
          year: obj.year,
          value: obj.value,
          meanScore: d3.mean(obj.score),
        };
      })
      .sort((a, b) => a.year - b.year);

    // Change the axis title when the dropdown changes
    vis.svg
      .select(".axis-title")
      .text(
        vis.selectedCriteria === "sales"
          ? "Total Sales /mil of units"
          : vis.selectedScore === "Critic"
          ? "Mean Critic Score"
          : "Mean User Score"
      );

    // Specify accessor functions
    vis.xValue = (d) => d.year;
    vis.yValue = (d) =>
      vis.selectedCriteria === "sales" ? d.value : d.meanScore;

    // Create a line generator to draw the line
    vis.line = d3
      .line()
      .x((d) => vis.xScale(vis.xValue(d)))
      .y((d) => vis.yScale(vis.yValue(d)));

    // Set the scale input domains
    vis.yScale.domain([
      vis.selectedCriteria === "sales"
        ? 0
        : vis.selectedScore === "Critic"
        ? 65
        : d3.min(vis.aggregatedData, vis.yValue) - 10,
      d3.max(vis.aggregatedData, vis.yValue),
    ]);

    vis.renderVis();
  }

  /**
   * Bind data to visual elements
   */
  renderVis() {
    let vis = this;

    // Add line path
    vis.chart
      .selectAll(".chart-line")
      .data([vis.aggregatedData])
      .join("path")
      .transition()
      .duration(800)
      .attr("class", "chart-line")
      .attr("d", vis.line)
      .attr("fill", "none")
      .attr("stroke", "steelblue")
      .attr("stroke-width", 1.5);

    // Add points for each year
    const points = vis.chart
      .selectAll(".point")
      .data(vis.aggregatedData)
      .join("circle")
      .attr("class", (d) =>
        selectedYears.includes(d.year.getFullYear())
          ? `point select year-${d.year.getFullYear()}`
          : `point default year-${d.year.getFullYear()}`
      );

    points
      .on("click", function (event, d) {
        // When a point is clicked, switch state between highlighted and not highlighted
        // Invalidate all selected points when the slider was previously used
        // Update all interactions
        if (vis.selectedBy === "slider") {
          selectedYears = [];
          vis.selectedBy = "point";
        }

        const isActive = selectedYears.includes(d.year.getFullYear());
        if (isActive) {
          selectedYears = selectedYears.filter(
            (f) => f !== d.year.getFullYear()
          ); // Remove from list
          d3.select(this).attr(
            "class",
            (d) => `point default year-${d.year.getFullYear()}`
          );
        } else {
          selectedYears.push(d.year.getFullYear()); // Append to list
          d3.select(this).attr(
            "class",
            (d) => `point select year-${d.year.getFullYear()}`
          );
        }

        // Remove the previous selected year for the search/random game
        SelectGame = "";

        vis.updateVis();
        updateTable();
        updateHeatMap();
        updateBubbleChart();
      })
      .on("mousemove", (event, d) => {
        // display a tooltip when hover
        d3
          .select("#tooltip")
          .style("display", "block")
          .style("left", event.pageX + vis.config.tooltipPadding + "px")
          .style("top", event.pageY + vis.config.tooltipPadding + "px").html(`
              <div class="tooltip-title">Year ${d.year.getFullYear()}</div>
              <div><i>${
                vis.selectedCriteria === "sales"
                  ? "Total Sales"
                  : vis.selectedScore === "Critic"
                  ? "Mean Critic Score"
                  : "Mean User Score"
              }: 
              ${
                vis.selectedCriteria === "sales"
                  ? d.value.toFixed(2)
                  : d.meanScore.toFixed(2)
              }</i></div>`);
      })
      .on("mouseleave", () => {
        d3.select("#tooltip").style("display", "none");
      });

    // Points transition
    points
      .transition()
      .duration(800)
      .attr("r", (d) =>
        d.year.getFullYear() === SelectGame.Year_of_Release ? 6 : 4
      )
      .attr("fill", (d) =>
        d.year.getFullYear() === SelectGame.Year_of_Release
          ? "hotpink"
          : "steelblue"
      )
      .attr("cy", (d) => vis.yScale(vis.yValue(d)))
      .attr("cx", (d) => vis.xScale(vis.xValue(d)));

    // Remove all selected/searched/random output games if clicked on the chart (not on the circles)
    vis.svg.on("mousedown", function (event) {
      if (event.target.tagName === "rect") {
        if (SelectGame !== "") {
          resetSearch();
        }
        selectedYears = [];
        vis.updateVis();
        updateTable(vis.data);
        updateBubbleChart();
        updateHeatMap();
      }
    });

    // Update the axes
    vis.xAxisG.call(vis.xAxis);
    vis.yAxisG.call(vis.yAxis);

    // Remove the top y-axis line
    d3.select(".x-axis .domain").remove();
    d3.select(".y-axis .domain").remove();
  }
}
